This case study is based on a dependable cluster of workstations, taken from [HHK00].

For more information, see: http://www.prismmodelchecker.org/casestudies/cluster.php

=====================================================================================

[HHK00]
B. Haverkort, H. Hermanns and J.-P. Katoen
On the use of model checking techniques for dependability evaluation
In Proc. 19th IEEE Symposium on Reliable Distributed Systems (SRDS'00), 228-237, 2000
